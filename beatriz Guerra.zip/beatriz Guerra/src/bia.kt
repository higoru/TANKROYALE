import dev.robocode.tankroyale.botapi.Bot
import dev.robocode.tankroyale.botapi.BotInfo
import dev.robocode.tankroyale.botapi.events.ScannedBotEvent

class bia: Bot(BotInfo.fromFile("res/bia.json")) {
    var dist = 50
    var isScanning = false
    override fun run() {
        while (isRunning) {
            forward(100.0)
            if (isScanning) {

                go()
            } else {

                turnGunLeft(5.0)

            }
        }
    }
    override fun onScannedBot(e: ScannedBotEvent) {
        isScanning = true

        val distance = distanceTo(e.x, e.y)
        if (distance < 50 && energy > 50) {
            fire(3.0)
        } else {

            fire(1.0)
        }

        scan()
        isScanning = false
    }
}
fun main(){
    bia().start()
}